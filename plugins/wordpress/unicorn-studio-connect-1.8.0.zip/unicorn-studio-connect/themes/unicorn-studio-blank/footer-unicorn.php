<?php
// Render Global Footer Component
if (class_exists('Unicorn_Studio_Global_Components')) {
    Unicorn_Studio_Global_Components::render_footer();
}
?>

<?php wp_footer(); ?>
</body>
</html>
